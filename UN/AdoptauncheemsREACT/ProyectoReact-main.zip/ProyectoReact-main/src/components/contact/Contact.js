/*#############################################
                 Importaciones
###############################################*/

//Modulos
//Estilos
import './Contact.css'
//Componentes
//Core

/*#############################################
                 Logica
###############################################*/
const Contact = () => {//Funcion constructora

    return(
        
        <div>
        <p >
           Contact
        </p>
        <p >
           Contact
        </p>
        <p >
           Contact
        </p>
        <p >
           Contact
        </p>
        <p >
           Contact
        </p>
        <p >
           Contact
        </p>
        <p >
           Contact
        </p>
        <p >
           Contact
        </p>
        <p >
           Contact
        </p>
        <p >
           Contact
        </p>
        </div>

        
    )

}

/*#############################################
                 Exportacion
###############################################*/
export default Contact