/*#############################################
                 Importaciones
###############################################*/

//Modulos
//Estilos
import './modeloC.css'
//Componentes
//Core

/*#############################################
                 Logica
###############################################*/
const modeloC = () => {//Funcion constructora

    return(
        
        <p >
           modeloC
        </p>
        
    )

}

/*#############################################
                 Exportacion
###############################################*/
export default modeloC
