/*#############################################
                 Importaciones
###############################################*/

//Modulos
//Estilos
import './AboutUs.css'
//Componentes
//Core

/*#############################################
                 Logica
###############################################*/
const AboutUs = () => {//Funcion constructora

    return(
        
        <div>
        <p >
           AboutUs
        </p>
        <p >
           AboutUs
        </p>
        <p >
           AboutUs
        </p>
        <p >
           AboutUs
        </p>
        <p >
           AboutUs
        </p>
        <p >
           AboutUs
        </p>
        <p >
           AboutUs
        </p>
        <p >
           AboutUs
        </p>
        <p >
           AboutUs
        </p>
        <p >
           AboutUs
        </p>
        </div>

        
    )

}

/*#############################################
                 Exportacion
###############################################*/
export default AboutUs
